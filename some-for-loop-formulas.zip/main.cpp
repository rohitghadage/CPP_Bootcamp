/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

//some for loop imp formulas:::::::::::::::::::::::::::::::::::::::


#include <stdio.h>
#include<iostream>

int main()
{
    using namespace std;
    // int my_nums[] = {2, 3, 4, 5, 6};
    
    
   
    // for(int i:my_nums) {
    //     cout <<i<< endl;
    // }
   
        //op:2 3 4 5 6 
        
    // char a[]="rohit";
    // for(int i=0;a[i]!=0;i++)
    // {
    //     cout<<a[i]<<endl;
    // }
    
    // output:
    // r                                                                                                                             
    // o                                                                                                                             
    // h                                                                                                                             
    // i                                                                                                                             
    // t
    
//     char a[]="rohit";
//   // char *cp;
//     for( char *cp=a;*cp!=0;cp++)
//     {
//         cout<<*cp<<endl;
//     }
    // output:
    // r                                                                                                                             
    // o                                                                                                                             
    // h                                                                                                                             
    // i                                                                                                                             
    // t
    
    
    
    return 0;
}
